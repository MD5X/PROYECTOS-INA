window.addEventListener('load', function() {
    document.getElementById('btn-ins').addEventListener('click', function() {
        Swal.fire({
            position: "center",
            icon: "success",
            title: '<b class="titleAlert">¡Gracias por Inscribirte!</b>',
            html: '<b class="textAlert"> Inscripción exitosa',
            showConfirmButton: false,
            timer: 5000,
            padding: '3rem',
            allowOutsideClick: true,
            allowEnterkey: true,
            background: '#163040',
            showConfirmButton: true,
            confirmButtonText:'<SPAN class="textButton">¡Excelente!</SPAN>',
            confirmButtonColor: '#f2a341'
        })
    })
}); 
window.addEventListener('load', function() {
    document.getElementById('btn-botons').addEventListener('click', function() {
        Swal.fire({
            position: "center",
            icon: "success",
            title: '<b class="titleAlert">¡Gracias por Inscribirte!</b>',
            html: '<b class="textAlert">Inscripción exitosa',
            showConfirmButton: false,
            timer: 5000,
            padding: '3rem',
            allowOutsideClick: true,
            allowEnterkey: true,
            background: '#163040',
            showConfirmButton: true,
            confirmButtonText:'<SPAN class="textButton">¡Excelente!</SPAN>',
            confirmButtonColor: '#f2a341'
        })
    })
}); 